# WASD Site: Local AI Model Integration Bridge

This directory contains a lightweight Python API server (`server.py`) that bridges the WASD Launchpad UI (running in your web browser) with your local AI model (running in Ollama or LM Studio).

Using this proxy, the Launchpad web application can:
1. **Detect** if your local LLM server is online.
2. **Execute Real Prompts** silently in the background using your local model.
3. **Write Physical Output Files** directly to your disk under `/products` when you click the "Build" button.

---

## 🛠️ Getting Started

### 1. Launch Your Local LLM Provider

Make sure you have one of the following running:

#### Option A: Ollama (Recommended)
1. Download and run Ollama from [ollama.com](https://ollama.com).
2. Pull a model (e.g. Llama 3) in your terminal:
   ```bash
   ollama pull llama3
   ```
3. Ollama runs automatically on `http://localhost:11434`.

#### Option B: LM Studio
1. Open LM Studio and download a model (e.g. `Meta-Llama-3-8B-Instruct`).
2. Go to the **Local Server** tab (the double arrow icon on the left).
3. Select your model and click **Start Server**.
4. LM Studio runs the API endpoint on `http://localhost:1234`.

---

### 2. Start the Proxy Server

No package installation (`pip`) is required! The script runs on Python's built-in modules.

Run the following command in your terminal/PowerShell inside the project directory:

```bash
python local-model/server.py
```

You should see:
```text
=========================================================
  WASD Local Model Proxy Server active on port 5000
  Workspace target: C:\Users\userpc\OneDrive\Desktop\Project CM S\WASD SITE
  Press Ctrl+C to terminate.
=========================================================
```

---

### 3. Open the Launchpad App
Once the proxy server is running, refresh `index.html` in your browser. The header indicator will glow **green** with status `Local Server: CONNECTED`.

The platform will now feed prompts to your local model silently in the background and physicalize files on your disk.
