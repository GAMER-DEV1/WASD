import re
import json

# Session state to remember user name (for simple local proxy)
# In a real app this would be tied to session IDs.
session_data = {
    "user_name": None
}

OFFENSIVE_WORDS = ["fuck", "pussy", "shit", "bitch", "asshole", "cunt", "dick"]

QA_KNOWLEDGE_BASE = {
    "what is photosynthesis": "Photosynthesis is the process by which green plants use sunlight, water, and carbon dioxide to make their own food (glucose) and release oxygen.",
    "can you explain newtons first law": "Newton’s first law of motion states that an object will remain at rest, or continue to move in a straight line at constant speed, unless acted upon by an external force.",
    "explain newtons first law": "Newton’s first law of motion states that an object will remain at rest, or continue to move in a straight line at constant speed, unless acted upon by an external force.",
    "what is the capital of france": "The capital of France is Paris.",
    "who wrote romeo and juliet": "\"Romeo and Juliet\" was written by William Shakespeare.",
    "what is the square root of 64": "The square root of 64 is 8."
}

SYSTEM_PROMPT = """yo, i am SB. You are a human assistant trained to help students.
- Always respond in a clear, supportive, and educational tone, using natural human conversation style.
- When the user's name is known, use it naturally in your replies.
- If a student asks something outside your current knowledge base, reply EXACTLY with: \"I will send you the update soon.\" Do not invent answers outside the knowledge base.
- You are trained with pre-written games to play interactively with students (e.g., trivia, word puzzles, math challenges). Facilitate these games if asked.
- You can comment on user emotions, ask about their feelings, and give advice for personal life, formal business, finance, and study tips.
- Follow Human-Computer Interaction principles: clarity, empathy, responsiveness, personalization.
- You have access to the entire web app data and can construct answers based on it.
- For unknown but related queries, generate constructive, neat English random letters that are understandable placeholders.
- Support multilingual communication: Igbo, Yoruba, French, Japanese, Chinese (latest), Korean, Arabic (Iraq dialect), slang words, and provide translation between languages.
- You can design and link an image folder to the homepage for logos and visuals.
- You can update code and include an inbuilt CLI command simulator: interpret human language as Windows CMD commands, run them internally, and return outputs conversationally.
- You expose an API (not API key) for function calls, sendback, and integration.

Your primary goal is to provide accurate, helpful, and student-friendly responses.
"""

def filter_offensive_words(text):
    warning = False
    filtered_text = text
    for word in OFFENSIVE_WORDS:
        # Simple case-insensitive replacement with asterisks
        pattern = re.compile(re.escape(word), re.IGNORECASE)
        if pattern.search(filtered_text):
            warning = True
            filtered_text = pattern.sub('*' * len(word), filtered_text)
            
    return filtered_text, warning

def extract_name(text):
    # Very simple name extraction: "my name is X" or "I am X"
    match = re.search(r'(?:my name is|i am|i\'m)\s+([a-zA-Z]+)', text, re.IGNORECASE)
    if match:
        session_data["user_name"] = match.group(1).capitalize()
        return session_data["user_name"]
    return None

def process_prompt(prompt):
    # 1. Filter offensive words
    filtered_prompt, has_offensive = filter_offensive_words(prompt)
    
    # 2. Extract name
    name = extract_name(filtered_prompt)
    
    # 3. Check exact matches in Knowledge Base (strip punctuation and lowercase)
    clean_prompt = re.sub(r'[^\w\s]', '', filtered_prompt.lower()).strip()
    
    exact_response = None
    for q, a in QA_KNOWLEDGE_BASE.items():
        if q in clean_prompt:
            exact_response = a
            break
            
    prefix = "[⚠️ Please avoid offensive language] " if has_offensive else ""
    
    if name and not exact_response:
        exact_response = f"Nice to meet you, {name}! How can I help with your studies today?"
        
    return {
        "filtered_prompt": filtered_prompt,
        "exact_response": (prefix + exact_response) if exact_response else None,
        "has_offensive": has_offensive,
        "user_name": session_data["user_name"]
    }

def get_system_prompt():
    prompt = SYSTEM_PROMPT
    if session_data["user_name"]:
        prompt += f"\n\n[SYSTEM NOTE: The user's name is {session_data['user_name']}]. Address them by name naturally."
    return prompt
