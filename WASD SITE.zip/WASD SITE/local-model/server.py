import os
import json
import knowledge_base
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.request
import urllib.error
import threading

# Initialize the native transformer model pipeline
# We load this in a separate thread to avoid blocking the main server startup if needed, 
# but for simplicity we can load it globally.
try:
    from transformers import pipeline
    print("Loading native AI model (TinyLlama)... this may take a moment.")
    chatbot = pipeline("text-generation", model="TinyLlama/TinyLlama-1.1B-Chat-v1.0", device_map="auto")
    print("Native AI model loaded successfully.")
except ImportError:
    chatbot = None
    print("WARNING: 'transformers' or 'torch' not installed. Inbuilt AI bot will not work.")
PORT = 5000
WORKSPACE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class LocalModelProxyHandler(BaseHTTPRequestHandler):
    
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == '/api/health':
            self._handle_health()
        else:
            self.send_error(404, "Endpoint not found")

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data.decode('utf-8'))
        except Exception as e:
            self._respond_json({"error": "Invalid JSON"}, 400)
            return

        if self.path == '/api/proxy-llm':
            self._handle_proxy_llm(data)
        elif self.path == '/api/write-product':
            self._handle_write_product(data)
        else:
            self.send_error(404, "Endpoint not found")

    def _respond_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def _handle_health(self):
        # We now use the native inbuilt model, so we report its status
        inbuilt_status = "online" if chatbot is not None else "offline"

        self._respond_json({
            "status": "online",
            "workspace": WORKSPACE_DIR,
            "providers": {
                "inbuilt": {
                    "status": inbuilt_status,
                    "url": "local"
                },
                "ollama": { "status": "offline", "url": "" },
                "lmstudio": { "status": "offline", "url": "" }
            }
        })

    def _handle_proxy_llm(self, payload):
        prompt = payload.get("prompt", "")
        # We ignore the frontend's system_prompt to enforce the knowledge base persona.

        if not prompt:
            self._respond_json({"error": "Prompt is required"}, 400)
            return

        # 1. Process via Knowledge Base first (handles filtering, exact matches, name extraction)
        kb_result = knowledge_base.process_prompt(prompt)
        
        if kb_result["exact_response"]:
            self._respond_json({"success": True, "text": kb_result["exact_response"]})
            return

        if chatbot is None:
            self._respond_json({
                "success": False, 
                "error": "Native AI model is not loaded. Ensure transformers and torch are installed."
            }, 500)
            return

        # 2. Fetch the dynamic system prompt (includes name if known)
        system_prompt = knowledge_base.get_system_prompt()

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": kb_result["filtered_prompt"]}
        ]

        try:
            # Generate response
            response = chatbot(messages, max_new_tokens=512, do_sample=True, temperature=0.7)
            # The pipeline returns a list of dicts. We extract the generated text.
            output_text = response[0]['generated_text'][-1]['content']
            self._respond_json({"success": True, "text": output_text})
        except Exception as e:
            self._respond_json({"success": False, "error": str(e)}, 500)

    def _handle_write_product(self, payload):
        folder_name = payload.get("folder_name", "")
        file_name = payload.get("file_name", "index.html")
        content = payload.get("content", "")

        if not folder_name or not content:
            self._respond_json({"error": "folder_name and content are required"}, 400)
            return

        # Sanitize folder name
        folder_name = "".join(c for c in folder_name if c.isalnum() or c in ('-', '_')).strip()
        if not folder_name:
            self._respond_json({"error": "Invalid folder name"}, 400)
            return

        target_dir = os.path.join(WORKSPACE_DIR, "products", folder_name)
        
        try:
            os.makedirs(target_dir, exist_ok=True)
            target_file = os.path.join(target_dir, file_name)
            
            with open(target_file, "w", encoding="utf-8") as f:
                f.write(content)

            self._respond_json({
                "success": True,
                "message": f"Successfully wrote file to {target_file}",
                "path": f"products/{folder_name}/{file_name}"
            })
        except Exception as e:
            self._respond_json({"success": False, "error": f"Failed to write file: {str(e)}"}, 500)

def run(server_class=HTTPServer, handler_class=LocalModelProxyHandler):
    server_address = ('', PORT)
    httpd = server_class(server_address, handler_class)
    print(f"=========================================================")
    print(f"  WASD Local Model Proxy Server active on port {PORT}")
    print(f"  Workspace target: {WORKSPACE_DIR}")
    print(f"  Press Ctrl+C to terminate.")
    print(f"=========================================================")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server.")
        httpd.server_close()

if __name__ == '__main__':
    run()
