// Global state
let currentStep = 1;
let selectedNiche = 'student-productivity';
let allOpportunities = [];
let top20Opportunities = [];
let selectedOpportunity = null;
let selectedPackaging = null;
let completedSteps = [1];

// Local Proxy Server Settings
let serverConnected = false;
let providersInfo = { inbuilt: "offline", ollama: "offline", lmstudio: "offline" };
let engineMode = 'sandbox'; // 'sandbox' or 'local'

// Template Sources to write physically to disk when "Build" is clicked
const productTemplates = {
    'resume-optimizer': {
        folder: 'resume-optimizer',
        fileName: 'index.html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Resume Optimizer - Resume Scanner</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap');
        :root {
            --bg-dark: #0b0c10;
            --bg-card: #1f2833;
            --primary: #66fcf1;
            --primary-glow: rgba(102, 252, 241, 0.2);
            --text-main: #c5c6c7;
            --text-bright: #ffffff;
            --border-color: rgba(255,255,255,0.08);
            --success: #2ecc71;
            --warning: #f1c40f;
            --error: #e74c3c;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-dark);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            max-width: 1000px;
            width: 100%;
            background: rgba(31, 40, 51, 0.45);
            backdrop-filter: blur(10px);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
        }
        header {
            margin-bottom: 24px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        h1 {
            font-family: 'Outfit', sans-serif;
            font-size: 1.6rem;
            color: var(--text-bright);
        }
        .badge {
            background: rgba(102, 252, 241, 0.1);
            color: var(--primary);
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 99px;
            border: 1px solid rgba(102, 252, 241, 0.2);
            font-weight: 600;
        }
        .panel-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
        }
        @media (max-width: 768px) {
            .panel-grid { grid-template-columns: 1fr; }
        }
        .panel { display: flex; flex-direction: column; gap: 16px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        label { font-size: 0.85rem; font-weight: 600; color: var(--text-bright); }
        textarea {
            width: 100%;
            height: 180px;
            background: rgba(11, 12, 16, 0.8);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 12px;
            color: var(--text-bright);
            font-family: inherit;
            font-size: 0.85rem;
            resize: none;
            outline: none;
            transition: border-color 0.2s;
        }
        textarea:focus { border-color: var(--primary); box-shadow: 0 0 8px var(--primary-glow); }
        .btn-analyze {
            background: linear-gradient(135deg, var(--primary) 0%, #1f9c94 100%);
            color: #0b0c10;
            border: none;
            border-radius: 8px;
            padding: 12px 20px;
            font-family: 'Outfit', sans-serif;
            font-weight: 700;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-analyze:hover { transform: translateY(-1px); box-shadow: 0 4px 12px var(--primary-glow); }
        .results-box {
            border: 1px solid var(--border-color);
            border-radius: 12px;
            background: rgba(11, 12, 16, 0.3);
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            min-height: 410px;
            justify-content: center;
        }
        .placeholder-state { text-align: center; color: #555; }
        .results-state { display: none; flex-direction: column; gap: 16px; animation: fadeIn 0.3s forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; } }
        .score-row { display: flex; align-items: center; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid var(--border-color); }
        .score-circle {
            width: 76px; height: 76px; border-radius: 50%; border: 4px solid var(--border-color);
            display: flex; align-items: center; justify-content: center;
            font-family: 'Outfit', sans-serif; font-size: 1.3rem; font-weight: 700; color: var(--primary);
        }
        .score-details h3 { font-family: 'Outfit', sans-serif; color: var(--text-bright); font-size: 1.1rem; }
        .tag-list { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
        .keyword-tag {
            font-size: 0.75rem; padding: 4px 8px; border-radius: 4px;
            background: rgba(231, 76, 60, 0.1); color: #ff6b6b; border: 1px solid rgba(231, 76, 60, 0.2);
        }
        .keyword-tag.matched {
            background: rgba(46, 204, 113, 0.1); color: #2ecc71; border: 1px solid rgba(46, 204, 113, 0.2);
        }
        .suggestion-card { background: rgba(255,255,255,0.02); border: 1px solid var(--border-color); border-radius: 6px; padding: 12px; font-size: 0.8rem; }
        .suggestion-header { font-weight: 600; color: var(--warning); margin-bottom: 4px; }
        .loading-state { display: none; flex-direction: column; align-items: center; gap: 12px; }
        .spinner {
            width: 40px; height: 40px; border: 4px solid rgba(102, 252, 241, 0.1);
            border-radius: 50%; border-top-color: var(--primary); animation: spin 1s infinite linear;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📄 AI Resume Optimizer</h1>
            <span class="badge">ATS Score Audit</span>
        </header>
        <div class="panel-grid">
            <div class="panel">
                <div class="form-group">
                    <label>Your Resume Text</label>
                    <textarea id="input-resume" placeholder="Paste your resume content here..."></textarea>
                </div>
                <div class="form-group">
                    <label>Job Description Requirements</label>
                    <textarea id="input-job" placeholder="Paste the job requirements description..."></textarea>
                </div>
                <button class="btn-analyze" onclick="runAnalysis()">Analyze Resume</button>
            </div>
            <div class="panel">
                <label>Audit Breakdown</label>
                <div class="results-box">
                    <div class="placeholder-state" id="res-placeholder">
                        <p style="font-weight: 600; color: var(--text-bright); margin-bottom: 4px;">Awaiting Scanning</p>
                        <p style="font-size: 0.8rem; max-width: 280px; margin: 0 auto; line-height: 1.4;">Fill in the target job specifications and paste your profile details to evaluate ATS compatibility metrics.</p>
                    </div>
                    <div class="loading-state" id="res-loading">
                        <div class="spinner"></div>
                        <p style="font-size: 0.8rem;">Extracting attributes, checking keyword densities...</p>
                    </div>
                    <div class="results-state" id="res-data">
                        <div class="score-row">
                            <div class="score-details">
                                <h3 id="report-match-title">Match Level: -</h3>
                                <p id="report-match-desc">Scanning analysis completed.</p>
                            </div>
                            <div class="score-circle" id="report-score">0%</div>
                        </div>
                        <div>
                            <p style="font-size: 0.8rem; font-weight: 600; margin-bottom: 6px; color: var(--text-bright);">Keywords Flagged:</p>
                            <div class="tag-list" id="report-keywords"></div>
                        </div>
                        <div class="suggestion-card">
                            <div class="suggestion-header">💡 Impact Strategy Recommendation</div>
                            <p id="report-bullet-suggestion"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function runAnalysis() {
            const resume = document.getElementById('input-resume').value.trim();
            const job = document.getElementById('input-job').value.trim();
            if(!resume || !job) { alert("Please fill both input fields."); return; }
            document.getElementById('res-placeholder').style.display = 'none';
            document.getElementById('res-data').style.display = 'none';
            document.getElementById('res-loading').style.display = 'flex';
            setTimeout(() => {
                document.getElementById('res-loading').style.display = 'none';
                document.getElementById('res-data').style.display = 'flex';
                const keywords = [
                    {word:'javascript', label:'JavaScript'}, {word:'python', label:'Python'},
                    {word:'react', label:'React'}, {word:'html', label:'HTML/CSS'},
                    {word:'sql', label:'SQL'}, {word:'cloud', label:'Cloud Services'},
                    {word:'agile', label:'Agile Project Methodologies'}, {word:'git', label:'Git / Code Management'}
                ];
                let missing = []; let matched = [];
                keywords.forEach(k => {
                    if(job.toLowerCase().includes(k.word)) {
                        if(resume.toLowerCase().includes(k.word)) matched.push(k.label);
                        else missing.push(k.label);
                    }
                });
                if(missing.length === 0 && matched.length === 0) {
                    missing = ['React Framework', 'Agile Workflows', 'Database Design'];
                    matched = ['JavaScript', 'HTML/CSS'];
                }
                const score = Math.max(15, Math.min(99, Math.round((matched.length / (missing.length + matched.length || 1)) * 100)));
                const scoreBox = document.getElementById('report-score');
                scoreBox.innerText = score + '%';
                const title = document.getElementById('report-match-title');
                const desc = document.getElementById('report-match-desc');
                const suggest = document.getElementById('report-bullet-suggestion');
                
                if(score >= 80) {
                    title.innerText = "Match Level: High"; title.style.color = "var(--success)";
                    desc.innerText = "Excellent alignment! Your resume passes the minimum threshold guidelines.";
                    suggest.innerText = "Quantify your achievements: substitute generic bullet points with exact metrics (e.g., 'saved 15 hours of manual work weekly').";
                } else {
                    title.innerText = "Match Level: Low"; title.style.color = "var(--error)";
                    desc.innerText = "Your profile is missing critical technical keywords.";
                    suggest.innerText = "Directly insert missing terms: " + missing.join(', ') + ". Lead sentences with strong action verbs.";
                }
                const tagCont = document.getElementById('report-keywords');
                tagCont.innerHTML = '';
                matched.forEach(m => { tagCont.innerHTML += '<span class="keyword-tag matched">✔ ' + m + '</span>'; });
                missing.forEach(m => { tagCont.innerHTML += '<span class="keyword-tag">❌ ' + m + '</span>'; });
            }, 1000);
        }
    </script>
</body>
</html>`
    },
    'questionnaire-reviewer': {
        folder: 'questionnaire-reviewer',
        fileName: 'index.html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Questionnaire Grader</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap');
        :root {
            --bg-dark: #080711;
            --bg-card: #141226;
            --primary: #9d4edd;
            --primary-glow: rgba(157, 78, 221, 0.2);
            --secondary: #e0aaff;
            --text-main: #d3d3e3;
            --text-bright: #ffffff;
            --border-color: rgba(255,255,255,0.06);
            --success: #06d6a0;
            --warning: #ffd166;
            --error: #ef476f;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-dark); color: var(--text-main); font-family: 'Inter', sans-serif;
            min-height: 100vh; padding: 40px 20px; display: flex; justify-content: center; align-items: center;
        }
        .container {
            max-width: 1000px; width: 100%; background: rgba(20, 18, 38, 0.5); backdrop-filter: blur(12px);
            border: 1px solid var(--border-color); border-radius: 16px; padding: 30px; box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
        }
        header { margin-bottom: 24px; border-bottom: 1px solid var(--border-color); padding-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
        h1 { font-family: 'Outfit', sans-serif; font-size: 1.5rem; color: var(--text-bright); }
        .badge { background: rgba(157, 78, 221, 0.1); color: var(--secondary); font-size: 0.75rem; padding: 4px 10px; border-radius: 99px; border: 1px solid rgba(157, 78, 221, 0.2); }
        .panel-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        @media (max-width: 768px) { .panel-grid { grid-template-columns: 1fr; } }
        .panel { display: flex; flex-direction: column; gap: 16px; }
        .form-group { display: flex; flex-direction: column; gap: 8px; }
        label { font-size: 0.85rem; font-weight: 600; color: var(--text-bright); }
        select {
            width: 100%; background: #080711; border: 1px solid var(--border-color);
            border-radius: 8px; padding: 10px; color: var(--text-bright); font-family: inherit; outline: none;
        }
        textarea {
            width: 100%; height: 180px; background: rgba(8, 7, 17, 0.8); border: 1px solid var(--border-color);
            border-radius: 8px; padding: 12px; color: var(--text-bright); font-family: inherit; font-size: 0.85rem; resize: none; outline: none;
        }
        textarea:focus { border-color: var(--primary); box-shadow: 0 0 8px var(--primary-glow); }
        .btn-grade {
            background: linear-gradient(135deg, var(--primary) 0%, #7b2cbf 100%); color: white; border: none;
            border-radius: 8px; padding: 12px 20px; font-family: 'Outfit', sans-serif; font-weight: 700; cursor: pointer; transition: all 0.2s;
        }
        .btn-grade:hover { transform: translateY(-1px); box-shadow: 0 4px 12px var(--primary-glow); }
        .results-box { border: 1px solid var(--border-color); border-radius: 12px; background: rgba(8, 7, 17, 0.3); padding: 20px; min-height: 410px; display: flex; flex-direction: column; justify-content: center; }
        .placeholder-state { text-align: center; color: #555; }
        .results-state { display: none; flex-direction: column; gap: 16px; animation: fadeIn 0.3s forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; } }
        .grade-row { display: flex; align-items: center; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid var(--border-color); }
        .grade-badge {
            width: 70px; height: 70px; border-radius: 12px; border: 2px solid var(--border-color);
            display: flex; align-items: center; justify-content: center; font-family: 'Outfit', sans-serif; font-size: 2.2rem; font-weight: 800;
        }
        .grade-details h3 { font-family: 'Outfit', sans-serif; color: var(--text-bright); font-size: 1.1rem; }
        .findings-list { display: flex; flex-direction: column; gap: 10px; }
        .finding-item { background: rgba(255,255,255,0.01); border: 1px solid var(--border-color); border-radius: 8px; padding: 12px; }
        .finding-tag { font-size: 0.65rem; font-weight: 700; text-transform: uppercase; padding: 2px 6px; border-radius: 4px; display: inline-block; margin-bottom: 6px; }
        .tag-error { background: rgba(239, 71, 111, 0.1); color: var(--error); border: 1px solid rgba(239, 71, 111, 0.2); }
        .tag-success { background: rgba(6, 214, 160, 0.1); color: var(--success); border: 1px solid rgba(6, 214, 160, 0.2); }
        .revision-box { border: 1px dashed rgba(157, 78, 221, 0.3); background: rgba(157, 78, 221, 0.03); border-radius: 8px; padding: 12px; font-size: 0.8rem; }
        .loading-state { display: none; flex-direction: column; align-items: center; gap: 12px; }
        .spinner { width: 40px; height: 40px; border: 4px solid rgba(157, 78, 221, 0.1); border-radius: 50%; border-top-color: var(--primary); animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📝 Thesis Questionnaire Auditor</h1>
            <span class="badge">Academic Scorer</span>
        </header>
        <div class="panel-grid">
            <div class="panel">
                <div class="form-group">
                    <label>Domain</label>
                    <select id="major-select">
                        <option>Social Sciences</option>
                        <option>Business Analytics</option>
                        <option>STEM Projects</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Draft Questionnaire Items</label>
                    <textarea id="input-questions" placeholder="Paste draft survey questions..."></textarea>
                </div>
                <button class="btn-grade" onclick="runAudit()">Audit Survey Questions</button>
            </div>
            <div class="panel">
                <label>Audit Analytics</label>
                <div class="results-box">
                    <div class="placeholder-state" id="res-placeholder">
                        <p style="font-weight: 600; color: var(--text-bright); margin-bottom: 4px;">Awaiting Drafts</p>
                        <p style="font-size: 0.8rem; max-width: 280px; margin: 0 auto; line-height: 1.4;">Paste your questionnaire list to analyze leading questions, double-barreled metrics, or phrase ambiguities.</p>
                    </div>
                    <div class="loading-state" id="res-loading">
                        <div class="spinner"></div>
                        <p style="font-size: 0.8rem;">Reviewing methodology formats...</p>
                    </div>
                    <div class="results-state" id="res-data">
                        <div class="grade-row">
                            <div class="grade-details">
                                <h3 id="report-grade-title">Grade: -</h3>
                                <p>Methodology assessment complete.</p>
                            </div>
                            <div class="grade-badge" id="report-grade-badge">A</div>
                        </div>
                        <div class="findings-list" id="report-findings"></div>
                        <div class="revision-box">
                            <p style="font-weight: 600; margin-bottom: 4px; color: var(--secondary)">💡 Suggested Phrasing Adjustment:</p>
                            <p id="report-revision-text"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function runAudit() {
            const val = document.getElementById('input-questions').value.trim();
            if(!val) { alert("Please input questions."); return; }
            document.getElementById('res-placeholder').style.display = 'none';
            document.getElementById('res-data').style.display = 'none';
            document.getElementById('res-loading').style.display = 'flex';
            setTimeout(() => {
                document.getElementById('res-loading').style.display = 'none';
                document.getElementById('res-data').style.display = 'flex';
                
                const hasBias = val.toLowerCase().includes('don\\'t you') || val.toLowerCase().includes('agree that');
                const hasDouble = val.toLowerCase().includes(' and ') || val.toLowerCase().includes(' or ');
                
                const gradeBadge = document.getElementById('report-grade-badge');
                const title = document.getElementById('report-grade-title');
                const list = document.getElementById('report-findings');
                const rev = document.getElementById('report-revision-text');
                
                list.innerHTML = '';
                
                if(hasBias || hasDouble) {
                    gradeBadge.innerText = 'C'; gradeBadge.style.color = 'var(--error)'; gradeBadge.style.borderColor = 'var(--error)';
                    title.innerText = 'Grade: C (Contains Fallacies)'; title.style.color = 'var(--error)';
                    
                    if(hasBias) {
                        list.innerHTML += '<div class="finding-item"><span class="finding-tag tag-error">Bias</span><p style="font-size:0.8rem; font-weight:600; color:var(--text-bright);">Leading questions detected</p><p style="font-size:0.75rem; margin-top:2px;">Phrasing pushes the respondent towards a predefined choice.</p></div>';
                    }
                    if(hasDouble) {
                        list.innerHTML += '<div class="finding-item"><span class="finding-tag tag-error">Complexity</span><p style="font-size:0.8rem; font-weight:600; color:var(--text-bright);">Double-Barreled item detected</p><p style="font-size:0.75rem; margin-top:2px;">You are querying multiple conditions in a single query.</p></div>';
                    }
                    rev.innerText = 'Rewrite items to isolate variables. Use Likert Scales (1-5) instead of yes/no prompts.';
                } else {
                    gradeBadge.innerText = 'A'; gradeBadge.style.color = 'var(--success)'; gradeBadge.style.borderColor = 'var(--success)';
                    title.innerText = 'Grade: A (Clean Design)'; title.style.color = 'var(--success)';
                    list.innerHTML += '<div class="finding-item"><span class="finding-tag tag-success">Passed</span><p style="font-size:0.8rem; font-weight:600; color:var(--text-bright);">Neutral Phrasing</p><p style="font-size:0.75rem; margin-top:2px;">Your draft features clear research syntax parameters.</p></div>';
                    rev.innerText = 'Ready for data collection. Proceed to publish.';
                }
            }, 1000);
        }
    </script>
</body>
</html>`
    },
    'study-buddy': {
        folder: 'study-buddy',
        fileName: 'index.html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Study Buddy Chatbot - Human Mode</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap');
        :root {
            --bg-dark: #0a0e17;
            --bg-card: rgba(22, 33, 54, 0.6);
            --primary: #38bdf8;
            --primary-glow: rgba(56, 189, 248, 0.2);
            --text-main: #94a3b8;
            --text-bright: #f8fafc;
            --border-color: rgba(255, 255, 255, 0.08);
            --message-user: #0369a1;
            --message-bot: rgba(30, 41, 59, 0.8);
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-dark); color: var(--text-main); font-family: 'Inter', sans-serif;
            min-height: 100vh; padding: 20px; display: flex; justify-content: center; align-items: center;
        }
        .container {
            max-width: 900px; width: 100%; height: 560px; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(16px);
            border: 1px solid var(--border-color); border-radius: 20px; display: grid; grid-template-columns: 240px 1fr; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        .sidebar { background: rgba(15, 23, 42, 0.95); border-right: 1px solid var(--border-color); display: flex; flex-direction: column; padding: 20px; gap: 20px; }
        .sidebar h2 { font-family: 'Outfit', sans-serif; font-size: 1.2rem; color: var(--text-bright); }
        .persona-btn {
            background: transparent; border: 1px solid var(--border-color); border-radius: 10px; padding: 10px;
            text-align: left; cursor: pointer; color: var(--text-main); display: flex; align-items: center; gap: 10px; width: 100%; margin-bottom: 8px;
        }
        .persona-btn.active { border-color: var(--primary); background: rgba(56, 189, 248, 0.1); color: var(--text-bright); }
        .persona-icon { font-size: 1.2rem; }
        .chat-area { display: flex; flex-direction: column; background: rgba(15, 23, 42, 0.2); height: 100%; }
        .chat-header { padding: 16px 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
        .chat-header h3 { font-family: 'Outfit', sans-serif; color: var(--text-bright); font-size: 1rem; }
        .chat-messages { flex-grow: 1; padding: 20px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; }
        .msg-row { display: flex; gap: 10px; max-width: 80%; animation: slideIn 0.2s ease-out; }
        .msg-row.user { align-self: flex-end; flex-direction: row-reverse; }
        .msg-row.bot { align-self: flex-start; }
        .msg-bubble { padding: 10px 14px; border-radius: 12px; font-size: 0.85rem; line-height: 1.4; }
        .msg-row.user .msg-bubble { background: var(--message-user); color: white; border-top-right-radius: 2px; }
        .msg-row.bot .msg-bubble { background: var(--message-bot); color: var(--text-bright); border: 1px solid var(--border-color); border-top-left-radius: 2px; }
        .chat-input-bar { padding: 16px 20px; border-top: 1px solid var(--border-color); display: flex; gap: 10px; }
        .input-field { flex-grow: 1; background: #0a0e17; border: 1px solid var(--border-color); border-radius: 8px; padding: 10px 14px; color: var(--text-bright); font-family: inherit; font-size: 0.85rem; outline: none; }
        .btn-send { background: var(--primary); color: #0f172a; border: none; border-radius: 8px; padding: 0 16px; font-weight: 700; cursor: pointer; }
        .typing-indicator { display: flex; gap: 4px; align-items: center; height: 16px; }
        .typing-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--text-main); animation: blink 1.4s infinite both; }
        .typing-dot:nth-child(2) { animation-delay: .2s; }
        .typing-dot:nth-child(3) { animation-delay: .4s; }
        @keyframes blink { 0%, 100% { opacity: .2; } 50% { opacity: 1; } }
        @keyframes slideIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; } }
    </style>
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>Study Buddy</h2>
            <div style="margin-top: 12px;">
                <button class="persona-btn active" id="btn-socratic" onclick="switchPersona('socratic')">
                    <span class="persona-icon">🧠</span>
                    <span>Socratic Tutor</span>
                </button>
                <button class="persona-btn" id="btn-coach" onclick="switchPersona('coach')">
                    <span class="persona-icon">💻</span>
                    <span>Coding Coach</span>
                </button>
            </div>
        </aside>
        <main class="chat-area">
            <div class="chat-header">
                <h3 id="chat-header-title">🧠 Socratic Tutor</h3>
            </div>
            <div class="chat-messages" id="message-container"></div>
            <div class="chat-input-bar">
                <input type="text" class="input-field" id="user-input" placeholder="Ask a question..." onkeydown="if(event.key==='Enter')sendMessage()">
                <button class="btn-send" onclick="sendMessage()">Send</button>
            </div>
        </main>
    </div>
    <script>
        let p = 'socratic';
        const welcomes = {
            socratic: "Hello! I am your Socratic Tutor. I will ask questions to help you reach answers on your own. What subject are we looking at?",
            coach: "Hi! Coding Coach here. Drop your programming bugs or concepts, and let's optimize them!"
        };
        const replies = {
            socratic: ["What assumptions are you making?", "How would you break this problem into simpler steps?", "Why do you think that happens?"],
            coach: ["Let's check code boundaries. What does it return if input is empty?", "Here is a clean layout pattern.", "Try adding log outputs."]
        };
        function switchPersona(type) {
            p = type;
            document.querySelectorAll('.persona-btn').forEach(btn => btn.classList.remove('active'));
            document.getElementById('btn-' + type).classList.add('active');
            document.getElementById('chat-header-title').innerText = type === 'socratic' ? '🧠 Socratic Tutor' : '💻 Coding Coach';
            document.getElementById('message-container').innerHTML = '';
            appendMsg('bot', welcomes[type]);
        }
        function appendMsg(sender, text) {
            const container = document.getElementById('message-container');
            const row = document.createElement('div');
            row.className = 'msg-row ' + sender;
            const avatar = sender === 'user' ? '👤' : (p === 'socratic' ? '🧠' : '💻');
            row.innerHTML = '<div class="msg-avatar">' + avatar + '</div><div class="msg-bubble">' + text + '</div>';
            container.appendChild(row);
            container.scrollTop = container.scrollHeight;
        }
        function sendMessage() {
            const input = document.getElementById('user-input');
            const txt = input.value.trim();
            if(!txt) return;
            appendMsg('user', txt);
            input.value = '';
            
            // Show typing
            const container = document.getElementById('message-container');
            const typing = document.createElement('div');
            typing.className = 'msg-row bot';
            typing.id = 'typing';
            typing.innerHTML = '<div class="msg-avatar">' + (p==='socratic'?'🧠':'💻') + '</div><div class="msg-bubble"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>';
            container.appendChild(typing);
            container.scrollTop = container.scrollHeight;
            
            setTimeout(() => {
                document.getElementById('typing').remove();
                const pool = replies[p];
                appendMsg('bot', pool[Math.floor(Math.random() * pool.length)]);
            }, 800);
        }
        switchPersona('socratic');
    </script>
</body>
</html>`
    },
    'html-uploader-guide': {
        folder: 'html-uploader-guide',
        fileName: 'index.html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HTML Deployment Assistant</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap');
        :root {
            --bg-dark: #07090e;
            --bg-card: #111827;
            --primary: #6366f1;
            --secondary: #10b981;
            --text-main: #9ca3af;
            --text-bright: #ffffff;
            --border-color: rgba(255, 255, 255, 0.08);
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background-color: var(--bg-dark); color: var(--text-main); font-family: 'Inter', sans-serif;
            min-height: 100vh; padding: 40px 20px; display: flex; justify-content: center; align-items: center;
        }
        .container {
            max-width: 1000px; width: 100%; background: rgba(17, 24, 39, 0.5); backdrop-filter: blur(12px);
            border: 1px solid var(--border-color); border-radius: 16px; padding: 30px; box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
        }
        header { margin-bottom: 24px; border-bottom: 1px solid var(--border-color); padding-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
        h1 { font-family: 'Outfit', sans-serif; font-size: 1.5rem; color: var(--text-bright); }
        .badge { background: rgba(99, 102, 241, 0.15); color: #818cf8; font-size: 0.75rem; padding: 4px 8px; border-radius: 4px; }
        .layout-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        @media (max-width: 768px) { .layout-grid { grid-template-columns: 1fr; } }
        .section-title { font-family: 'Outfit', sans-serif; color: var(--text-bright); font-size: 1.1rem; margin-bottom: 12px; }
        .method-card { background: rgba(255,255,255,0.02); border: 1px solid var(--border-color); border-radius: 8px; padding: 14px; cursor: pointer; margin-bottom: 10px; }
        .method-card.active { border-color: var(--primary); background: rgba(99, 102, 241, 0.05); }
        .method-name { font-weight: 600; color: var(--text-bright); font-size: 0.9rem; }
        .instruction-pane { background: #090e16; border: 1px solid var(--border-color); border-radius: 8px; padding: 14px; font-size: 0.8rem; line-height: 1.4; margin-top: 12px; }
        .drop-zone { border: 2px dashed rgba(99, 102, 241, 0.3); background: rgba(99, 102, 241, 0.01); border-radius: 8px; padding: 30px; text-align: center; cursor: pointer; }
        .validator-report { background: #090e16; border: 1px solid var(--border-color); border-radius: 8px; padding: 14px; margin-top: 12px; display: none; }
        .status-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 6px; }
        .dot-green { background: #10b981; }
        .dot-yellow { background: #f59e0b; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🌐 HTML Uploader</h1>
            <span class="badge">Deployment Assistant</span>
        </header>
        <div class="layout-grid">
            <div>
                <div class="section-title">Hosting Methods</div>
                <div class="method-card active" id="btn-netlify" onclick="switchTab('netlify')">
                    <span class="method-name">Netlify Drop</span>
                    <p style="font-size:0.75rem; margin-top:2px;">Drag folders to get a live URL in seconds.</p>
                </div>
                <div class="method-card" id="btn-github" onclick="switchTab('github')">
                    <span class="method-name">GitHub Pages</span>
                    <p style="font-size:0.75rem; margin-top:2px;">Free automated portfolio hosting.</p>
                </div>
                <div class="instruction-pane" id="steps-pane"></div>
            </div>
            <div>
                <div class="section-title">Relative Path Validator</div>
                <div class="drop-zone" onclick="runValidation()">
                    <p style="font-weight:600; color:var(--text-bright);">Upload local project directory</p>
                    <p style="font-size:0.75rem; margin-top:4px;">Click to scan HTML/CSS linking formats.</p>
                </div>
                <div class="validator-report" id="report">
                    <div style="font-weight:600; color:var(--text-bright); border-bottom:1px solid var(--border-color); padding-bottom:6px; margin-bottom:8px;" id="report-title">Scan Complete</div>
                    <div id="report-items"></div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const instructions = {
            netlify: [
                "Open Netlify Drop (app.netlify.com/drop) in your browser.",
                "Drag your folder containing index.html directly into the drop zone.",
                "Your project goes live instantly! Claim your site to customize the URL subdomain."
            ],
            github: [
                "Push your files to a GitHub repository.",
                "Verify that your entry file is named index.html in lowercase.",
                "Go to Settings -> Pages, select main branch, and click save. Site launches in 1 minute."
            ]
        };
        function switchTab(type) {
            document.querySelectorAll('.method-card').forEach(c=>c.classList.remove('active'));
            document.getElementById('btn-'+type).classList.add('active');
            const pane = document.getElementById('steps-pane');
            pane.innerHTML = '';
            instructions[type].forEach((step, idx) => {
                pane.innerHTML += '<p style="margin-bottom:8px;"><strong>' + (idx+1) + '.</strong> ' + step + '</p>';
            });
        }
        function runValidation() {
            const report = document.getElementById('report');
            report.style.display = 'block';
            const items = document.getElementById('report-items');
            items.innerHTML = '<div style="margin-bottom:6px;"><span class="status-dot dot-green"></span> index.html located in root directory.</div>';
            items.innerHTML += '<div><span class="status-dot dot-green"></span> All imports use relative paths. Ready to upload!</div>';
        }
        switchTab('netlify');
    </script>
</body>
</html>`
    }
};

// Map of opportunity topics (Step 4 & 5 insights database)
const opportunityDB = {
    'resume-optimizer': {
        title: 'AI Resume Scanner & Keyword Matcher',
        folder: 'resume-optimizer',
        niche: 'Student Productivity',
        icon: '📄',
        score: 96,
        difficulty: 'Low',
        personaName: 'The Job-Seeking Senior',
        personaAvatar: '💼',
        personaDemog: 'Final-year student, preparing 50+ job applications, stressed about ATS screening.',
        need: 'Wants to instantly optimize resumes for specific job descriptions to bypass applicant tracking systems (ATS).',
        gap: 'Existing tools charge hefty subscriptions, store personal data, and lack student-specific resume formats.',
        baseScore: { demand: 98, ease: 95, margin: 95 }
    },
    'questionnaire-reviewer': {
        title: 'Dissertation Questionnaire Grader & Reviewer',
        folder: 'questionnaire-reviewer',
        niche: 'Student Productivity',
        icon: '📝',
        score: 94,
        difficulty: 'Low',
        personaName: 'The Research Student',
        personaAvatar: '🎓',
        personaDemog: 'Academic writer, final semester, preparing quantitative questionnaires for thesis approval.',
        need: 'Wants feedback on research questions to prevent survey bias and secure an "A" from the academic panel.',
        gap: 'Academic review processes are slow (weeks of waiting). No instant, client-side tools analyze leading or ambiguous phrasing.',
        baseScore: { demand: 95, ease: 92, margin: 95 }
    },
    'study-buddy': {
        title: 'AI Study-Buddy Chatbot (Human Mode)',
        folder: 'study-buddy',
        niche: 'Student Productivity',
        icon: '🤖',
        score: 92,
        difficulty: 'Medium',
        personaName: 'The Self-Taught Developer',
        personaAvatar: '💻',
        personaDemog: 'Coding bootcamp student or self-guided learner who needs explanation of tricky code concepts.',
        need: 'Wants an AI study assistant that gives friendly, unrestricted, human-like guidance and code walkthroughs.',
        gap: 'Standard AI models are dry, formal, and refuse to help with edge cases or bypass standard constraints.',
        baseScore: { demand: 93, ease: 90, margin: 93 }
    },
    'html-uploader-guide': {
        title: 'HTML Project Uploader & Instant Deployment Guide',
        folder: 'html-uploader-guide',
        niche: 'Student Productivity',
        icon: '🌐',
        score: 90,
        difficulty: 'Low',
        personaName: 'The First-Year Coder',
        personaAvatar: '🚀',
        personaDemog: 'Beginner web student with local HTML files, trying to deploy their first portfolio for clients.',
        need: 'Needs a dead-simple, drag-and-drop tool to deploy their static HTML projects to the web for free.',
        gap: 'Cloud hosting providers (AWS, GCP) have steep learning curves. Complex CLI setups overwhelm junior web design students.',
        baseScore: { demand: 92, ease: 95, margin: 85 }
    }
};

// Generative lists for programmatic generation fallback
const verbs = ['AI-Powered', 'Automated', 'Virtual', 'Instant', 'No-Code', 'Self-Hosted', 'Cloud-Based', 'Zero-Config'];
const nouns = {
    'student-productivity': ['Study Planner', 'Flashcard Maker', 'LaTeX Compiler', 'Bibliography Helper', 'Note Transcriber', 'Group Project Board', 'Syllabus Parser', 'Exam Quiz Generator', 'Grade Calculator', 'Attendance Tracker'],
    'ai-agents': ['Phone Agent', 'Voice Assistant', 'API Token Pool', 'Unrestricted Sandbox', 'Screen Controller', 'Reply Bot', 'Chat Simulator', 'Autonomous Debugger', 'Script Writer', 'Sentiment Engine'],
    'no-code': ['Web App Builder', 'API Endpoint Creator', 'Database Visualizer', 'SQL Generator', 'CSS Animation Sandbox', 'Markdown Blog Deployer', 'Portfolio Host', 'Form Builder', 'Webhook Capture', 'Email Template Compiler'],
    'eco-templates': ['Packaging Designer', 'Carbon Footprint Calculator', 'Supply Auditor', 'Green Delivery Route Optimizer', 'Eco-Audit Generator', 'Recycling Hub Locator', 'Energy Usage Monitor', 'Sustainable Material Directory', 'Eco Badge Generator', 'Paperless Invoice Designer']
};
const targets = ['for Students', 'for Developers', 'for Local Brands', 'for Remote Teams', 'for Creators', 'for Freelancers', 'for Researchers'];

// Check Local Proxy connection silently on startup
window.addEventListener('DOMContentLoaded', () => {
    checkLocalServerHealth();
    // Auto-check connection every 5 seconds silently
    setInterval(checkLocalServerHealth, 5000);
});

// Reset Wizard to Home screen
function goHome(e) {
    if (e) e.preventDefault();
    
    // Reset wizard variables
    currentStep = 1;
    completedSteps = [1];
    selectedOpportunity = null;
    selectedPackaging = null;
    allOpportunities = [];
    top20Opportunities = [];
    
    // Reset sidebar classes
    document.querySelectorAll('.step-card').forEach(sc => {
        sc.classList.remove('active', 'completed', 'clickable');
    });
    document.getElementById('step-btn-1').classList.add('active');
    
    // Go to first screen
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('screen-1').classList.add('active');
}

// Check local model proxy server status silently
function checkLocalServerHealth() {
    const statusDot = document.getElementById('connection-status-dot');
    const statusLbl = document.getElementById('connection-status-lbl');
    
    const widgetProxy = document.getElementById('widget-proxy-status');
    const widgetLLM = document.getElementById('widget-llm-status');
    const widgetInbuilt = document.getElementById('widget-inbuilt-status');
    
    fetch('http://localhost:5000/api/health')
        .then(res => res.json())
        .then(data => {
            serverConnected = true;
            providersInfo = data.providers;
            
            // Update UI indicators
            statusDot.className = 'status-indicator connected';
            statusLbl.innerText = 'Local Server: CONNECTED';
            
            widgetProxy.innerText = 'Connected (Port 5000)';
            
            // Check provider details
            const isInbuiltOnline = data.providers.inbuilt && data.providers.inbuilt.status === 'online';
            
            if (widgetInbuilt) widgetInbuilt.innerText = isInbuiltOnline ? 'Online' : 'Offline';
            
            // Set mode dropdown automatically if the user hasn't touched it yet
            const modeSelect = document.getElementById('engine-mode-select');
            if (engineMode === 'sandbox') {
                // If local server is running, we can default back to 'local'
                engineMode = 'local';
                modeSelect.value = 'local';
                updateWidgetLLM();
            }
        })
        .catch(err => {
            serverConnected = false;
            statusDot.className = 'status-indicator offline';
            statusLbl.innerText = 'Local Server: OFFLINE';
            
            widgetProxy.innerText = 'Offline (Sandbox)';
            widgetLLM.innerText = 'Local Mock';
            if (widgetInbuilt) widgetInbuilt.innerText = '-';
            
            const modeSelect = document.getElementById('engine-mode-select');
            engineMode = 'sandbox';
            modeSelect.value = 'sandbox';
        });
}

// Toggle between Sandbox and Local Mode
function toggleEngineMode() {
    const modeSelect = document.getElementById('engine-mode-select');
    engineMode = modeSelect.value;
    
    if (engineMode === 'local' && !serverConnected) {
        alert("The local proxy server.py is not running. Please run 'python local-model/server.py' in your command prompt first.");
        engineMode = 'sandbox';
        modeSelect.value = 'sandbox';
    }
    
    updateWidgetLLM();
}

function updateWidgetLLM() {
    const widgetLLM = document.getElementById('widget-llm-status');
    if (engineMode === 'sandbox') {
        widgetLLM.innerText = 'Local Mock';
    } else {
        const provider = document.getElementById('llm-provider-select').value;
        const model = document.getElementById('model-tag-input').value;
        widgetLLM.innerText = `${provider.toUpperCase()}: ${model}`;
    }
}

// Proxy call to local LLM server
async function callLocalLLM(prompt, systemPrompt = "") {
    if (engineMode === 'sandbox' || !serverConnected) {
        return null;
    }
    
    const provider = document.getElementById('llm-provider-select').value;
    const model = document.getElementById('model-tag-input').value;
    
    const payload = {
        provider: provider,
        model: model,
        prompt: prompt,
        system_prompt: systemPrompt
    };
    
    try {
        const res = await fetch('http://localhost:5000/api/proxy-llm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: jsonStringifySilent(payload)
        });
        const data = await res.json();
        if (data.success) {
            return data.text;
        } else {
            console.warn("LLM proxy returned error, falling back:", data.error);
            return null;
        }
    } catch (e) {
        console.warn("Failed LLM connection, falling back:", e);
        return null;
    }
}

// Silent JSON stringifier
function jsonStringifySilent(obj) {
    try {
        return JSON.stringify(obj);
    } catch(e) {
        return "";
    }
}

// Wizard state step routers
function navigateToStep(step) {
    if (step === currentStep) return;
    if (!completedSteps.includes(step) && step > Math.max(...completedSteps) + 1) return;
    
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.step-card').forEach(sc => sc.classList.remove('active'));
    
    document.getElementById(`screen-${step}`).classList.add('active');
    document.getElementById(`step-btn-${step}`).classList.add('active');
    
    currentStep = step;
}

function markStepCompleted(step) {
    if (!completedSteps.includes(step)) completedSteps.push(step);
    const card = document.getElementById(`step-btn-${step}`);
    card.classList.add('completed');
    card.classList.add('clickable');
}

// STEP 2: Idea Gen Click trigger
async function startIdeaGen() {
    navigateToStep(2);
    
    const container = document.getElementById('ideas-output-list');
    container.innerHTML = '';
    
    const scanBar = document.getElementById('scan-bar');
    const statScraped = document.getElementById('stat-scraped');
    const statMatched = document.getElementById('stat-matched');
    const statSpeed = document.getElementById('stat-speed');
    const nextBtn = document.getElementById('btn-next-to-scoring');
    
    scanBar.style.width = '0%';
    nextBtn.disabled = true;
    
    let promptAttribute = document.getElementById('custom-prompt-input').value.trim();
    
    // Check if we can query LLM for ideas
    let customIdeas = [];
    if (engineMode === 'local' && serverConnected) {
        const llmPrompt = `Generate 5 high-opportunity SaaS product names and short descriptions for the niche: ${selectedNiche}. ${promptAttribute ? 'Focus specifically on: ' + promptAttribute : ''} Return raw JSON format only like this: [{"name": "Name", "description": "Desc"}].`;
        const responseText = await callLocalLLM(llmPrompt, "You are a product database generator. Output only valid JSON arrays.");
        
        if (responseText) {
            try {
                // Extract JSON block if LLM wrapped in backticks
                let cleanJson = responseText.trim();
                if (cleanJson.includes('```')) {
                    cleanJson = cleanJson.split('```')[1].replace('json', '').trim();
                }
                const parsed = JSON.parse(cleanJson);
                if (Array.isArray(parsed)) {
                    customIdeas = parsed.map(item => ({
                        title: item.name,
                        niche: selectedNiche.replace('-', ' '),
                        isCustomLLM: true
                    }));
                }
            } catch(e) {
                console.warn("Failed parsing local LLM response, loading default seeds", e);
            }
        }
    }
    
    // Build list of 100
    allOpportunities = [];
    
    // Add the 4 core premium products
    const premKeys = Object.keys(opportunityDB);
    let idCounter = 1;
    premKeys.forEach(k => {
        const p = opportunityDB[k];
        allOpportunities.push({
            id: idCounter++,
            title: p.title,
            niche: p.niche,
            score: p.score,
            demand: p.baseScore.demand,
            ease: p.baseScore.ease,
            margin: p.baseScore.margin,
            difficulty: p.difficulty,
            key: k
        });
    });

    // Add LLM generated custom ideas if we have them
    customIdeas.forEach(ci => {
        const demand = Math.floor(Math.random() * 15 + 83); // higher score
        const ease = Math.floor(Math.random() * 20 + 75);
        const margin = Math.floor(Math.random() * 10 + 85);
        const score = Math.round((demand * 0.4) + (margin * 0.4) + (ease * 0.2));
        allOpportunities.push({
            id: idCounter++,
            title: ci.title,
            niche: ci.niche.toUpperCase(),
            score: score,
            demand: demand,
            ease: ease,
            margin: margin,
            difficulty: 'Low',
            key: null
        });
    });
    
    // Generate remaining to hit 100
    const nounsList = nouns[selectedNiche] || nouns['student-productivity'];
    while (allOpportunities.length < 100) {
        const v = verbs[Math.floor(Math.random() * verbs.length)];
        const n = nounsList[Math.floor(Math.random() * nounsList.length)];
        const t = targets[Math.floor(Math.random() * targets.length)];
        
        const title = `${v} ${n} ${t}`;
        if (allOpportunities.some(item => item.title === title)) continue;
        
        const demand = Math.floor(Math.random() * 45 + 50);
        const ease = Math.floor(Math.random() * 45 + 50);
        const margin = Math.floor(Math.random() * 40 + 55);
        const score = Math.round((demand * 0.4) + (margin * 0.4) + (ease * 0.2));
        
        allOpportunities.push({
            id: idCounter++,
            title: title,
            niche: selectedNiche.replace('-', ' ').toUpperCase(),
            score: score,
            demand: demand,
            ease: ease,
            margin: margin,
            difficulty: ease > 75 ? 'Low' : 'Medium',
            key: null
        });
    }
    
    // Animation routine
    let idx = 0;
    let matchHits = 0;
    const interval = setInterval(() => {
        if (idx >= 100) {
            clearInterval(interval);
            scanBar.style.width = '100%';
            nextBtn.disabled = false;
            markStepCompleted(2);
            return;
        }
        
        const op = allOpportunities[idx];
        if (op.score > 85) matchHits++;
        
        const item = document.createElement('div');
        item.className = 'idea-strip-item';
        item.innerHTML = `
            <span class="idea-strip-num">#${op.id}</span>
            <span class="idea-strip-text" title="${op.title}">${op.title}</span>
            <span class="idea-strip-niche">${op.niche}</span>
        `;
        container.appendChild(item);
        container.scrollTop = container.scrollHeight;
        
        idx++;
        scanBar.style.width = `${idx}%`;
        statScraped.innerText = idx * 114;
        statMatched.innerText = matchHits;
        statSpeed.innerText = Math.floor(Math.random() * 80 + 580);
    }, 25);
}

// Select Niche cards
function selectNiche(card) {
    document.querySelectorAll('.niche-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedNiche = card.getAttribute('data-niche');
}

// STEP 3: Table scoring
function startScoring() {
    navigateToStep(3);
    const tbody = document.getElementById('ranking-tbody');
    tbody.innerHTML = '';
    
    // Sort
    const sorted = [...allOpportunities].sort((a, b) => b.score - a.score);
    top20Opportunities = sorted.slice(0, 20);
    
    top20Opportunities.forEach((op, index) => {
        const tr = document.createElement('tr');
        tr.setAttribute('onclick', `selectTop20Opportunity(${index}, this)`);
        
        const scoreClass = op.score > 85 ? 'score-high' : 'score-medium';
        const marginLabel = op.margin > 85 ? 'High (80%+)' : 'Medium (60%+)';
        const marginClass = op.margin > 85 ? 'pot-high' : 'pot-med';
        
        if (index === 0) {
            tr.className = 'active-row';
            selectedOpportunity = op;
        }
        
        tr.innerHTML = `
            <td><div class="rank-badge">${index + 1}</div></td>
            <td class="cell-bold">${op.title}</td>
            <td>${op.niche}</td>
            <td>
                <div class="score-bar-bg">
                    <div class="score-bar-fill ${scoreClass}" style="width: ${op.score}%;"></div>
                </div>
                <span>${op.score}%</span>
            </td>
            <td><span class="potential-badge ${marginClass}">${marginLabel}</span></td>
        `;
        tbody.appendChild(tr);
    });
    
    markStepCompleted(3);
}

function selectTop20Opportunity(index, row) {
    document.querySelectorAll('#ranking-tbody tr').forEach(tr => tr.classList.remove('active-row'));
    row.classList.add('active-row');
    selectedOpportunity = top20Opportunities[index];
}

// STEP 4: Review Insights
function proceedToSelection() {
    navigateToStep(4);
    
    const selector = document.getElementById('insights-selector-list');
    selector.innerHTML = '';
    
    top20Opportunities.forEach((op, index) => {
        const item = document.createElement('div');
        item.className = 'selector-item';
        if (selectedOpportunity && selectedOpportunity.id === op.id) {
            item.classList.add('selected');
        }
        item.setAttribute('onclick', `insightsSelectOpportunity(${index}, this)`);
        
        item.innerHTML = `
            <span class="selector-item-text" title="${op.title}">${op.title}</span>
            <span class="selector-item-score">${op.score}%</span>
        `;
        selector.appendChild(item);
    });
    
    updateInsightsPanel();
    markStepCompleted(4);
}

function insightsSelectOpportunity(index, row) {
    document.querySelectorAll('#insights-selector-list .selector-item').forEach(i => i.classList.remove('selected'));
    row.classList.add('selected');
    selectedOpportunity = top20Opportunities[index];
    updateInsightsPanel();
}

function letAIChooseBest() {
    // Select first custom LLM or first premium
    let best = top20Opportunities.find(op => op.key !== null);
    if (!best) best = top20Opportunities[0];
    
    const items = document.querySelectorAll('#insights-selector-list .selector-item');
    top20Opportunities.forEach((op, idx) => {
        if (op.id === best.id) {
            insightsSelectOpportunity(idx, items[idx]);
            items[idx].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    });
}

function updateInsightsPanel() {
    if (!selectedOpportunity) return;
    
    const titleEl = document.getElementById('insight-display-title');
    const nicheEl = document.getElementById('insight-tag-niche');
    const scoreEl = document.getElementById('insight-tag-score');
    const diffEl = document.getElementById('insight-tag-difficulty');
    const avatarEl = document.getElementById('insight-persona-avatar');
    const nameEl = document.getElementById('insight-persona-name');
    const demogEl = document.getElementById('insight-persona-demog');
    const needEl = document.getElementById('insight-desc-need');
    const gapEl = document.getElementById('insight-desc-gap');
    
    const key = selectedOpportunity.key;
    if (key && opportunityDB[key]) {
        const p = opportunityDB[key];
        titleEl.innerText = p.title;
        nicheEl.innerText = p.niche;
        scoreEl.innerText = `Score: ${p.score}%`;
        diffEl.innerText = `Difficulty: ${p.difficulty}`;
        avatarEl.innerText = p.personaAvatar;
        nameEl.innerText = p.personaName;
        demogEl.innerText = p.personaDemog;
        needEl.innerText = p.need;
        gapEl.innerText = p.gap;
    } else {
        titleEl.innerText = selectedOpportunity.title;
        nicheEl.innerText = selectedOpportunity.niche;
        scoreEl.innerText = `Score: ${selectedOpportunity.score}%`;
        diffEl.innerText = `Difficulty: ${selectedOpportunity.difficulty}`;
        avatarEl.innerText = '💡';
        nameEl.innerText = 'The Modern Student Creator';
        demogEl.innerText = 'Indie hacker cohort trying to deploy client-friendly web assets fast.';
        needEl.innerText = `Searching for a simple automation toolkit to compile and execute: "${selectedOpportunity.title.toLowerCase()}" instantly.`;
        gapEl.innerText = 'Enterprise applications have strict billing filters and require hours of manual environment configurations.';
    }
}

// STEP 6: 20 Packaging Card Options
function proceedToPackaging() {
    navigateToStep(6);
    const container = document.getElementById('packaging-cards-container');
    container.innerHTML = '';
    
    const brandingStencils = [
        { name: 'Pure Student Freebie', badge: 'free', icon: '🎁', desc: 'Ad-supported client-side tool with optional tips. Zero server costs.' },
        { name: 'Self-Hosted Github Template', badge: 'premium', icon: '🛠️', desc: 'Deploy-to-Vercel template that users clone and run with their own API tokens.' },
        { name: 'Student Micro-SaaS Tier', badge: 'saas', icon: '💳', desc: '$1.99/mo bundle with unlimited scanner triggers and export credits.' },
        { name: 'The Resume Portfolio Bundle', badge: 'premium', icon: '💼', desc: 'Packaged app that matches resume, prints PDFs, and outputs static HTML portfolios.' },
        { name: 'Gumroad Product Code Delivery', badge: 'premium', icon: '🛒', desc: 'One-time $4.99 purchase delivering the offline codebase ready to edit.' },
        { name: 'Google Chrome Extension Wrapper', badge: 'saas', icon: '🧩', desc: 'Direct browser injection helping users scan pages on the fly.' },
        { name: 'Unlimited API Endpoint Proxy', badge: 'saas', icon: '🔗', desc: 'Developer token access providing unrestricted query pathways.' },
        { name: 'Educational White-Label Core', badge: 'premium', icon: '🏛️', desc: 'For departments/schools looking to self-host custom reviewer channels.' },
        { name: 'Netlify Deploy-Ready Kit', badge: 'free', icon: '⚡', desc: 'Static distribution folder packaged with drag-and-drop web hosting scripts.' },
        { name: 'The No-Auth Privacy-First Utility', badge: 'free', icon: '🔒', desc: 'Runs entirely in localStorage. No user accounts, completely anonymous.' },
        { name: 'The Study Group Multi-Seat Pack', badge: 'saas', icon: '👥', desc: '$5/mo for up to 5 team members sharing templates and logs.' },
        { name: 'Discord Bot Integration Suite', badge: 'saas', icon: '💬', desc: 'Interact with the product directly inside team channels.' },
        { name: 'Tailwind Dashboard Export Edition', badge: 'premium', icon: '🎨', desc: 'Includes source code styled with Tailwind CSS configs.' },
        { name: 'Offline Desktop Native Electron', badge: 'premium', icon: '🖥️', desc: 'Double-clickable native app for Mac and Windows environments.' },
        { name: 'The Final Year Thesis Bundle', badge: 'premium', icon: '📚', desc: 'Reviewer tools combined with APA formatting and PDF proofing templates.' },
        { name: 'Voice-Note Mobile Add-on', badge: 'saas', icon: '🎙️', desc: 'Voice-to-text transcript portal built for offline lectures.' },
        { name: 'Dorm-Room Solar Monitor Kit', badge: 'premium', icon: '☀️', desc: 'Green design styles ready-made for eco projects.' },
        { name: 'Socratic Tutor Persona Pack', badge: 'free', icon: '🧠', desc: 'Chat interface tuned to guide users instead of directly feeding answers.' },
        { name: 'Instant Mock API Server Sandbox', badge: 'free', icon: '📦', desc: 'Runs local mock APIs for student prototyping without payment.' },
        { name: 'The Client-Facing Freelance Portal', badge: 'premium', icon: '🤝', desc: 'Client portal enabling developers to upload projects for review.' }
    ];
    
    brandingStencils.forEach((stencil, index) => {
        const card = document.createElement('div');
        card.className = 'packaging-card';
        card.setAttribute('onclick', `selectPackaging(${index}, this)`);
        if (index === 0) {
            card.classList.add('selected');
            selectedPackaging = stencil;
        }
        
        card.innerHTML = `
            <div class="pkg-icon">${stencil.icon}</div>
            <div class="pkg-title">${stencil.name}</div>
            <div class="pkg-desc">${stencil.desc}</div>
            <div class="pkg-badge pkg-badge-${stencil.badge}">${stencil.badge}</div>
        `;
        container.appendChild(card);
    });
    
    markStepCompleted(6);
}

function selectPackaging(index, card) {
    document.querySelectorAll('#packaging-cards-container .packaging-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedPackaging = {
        name: card.querySelector('.pkg-title').innerText,
        badge: card.querySelector('.pkg-badge').innerText
    };
}

// STEP 7: Asset writing & Compilation
function proceedToBuild() {
    navigateToStep(7);
    
    const terminal = document.getElementById('build-terminal-log');
    terminal.innerHTML = '';
    
    const banner = document.getElementById('build-success-banner');
    banner.style.display = 'none';
    
    const backBtn = document.getElementById('btn-build-back');
    backBtn.disabled = true;
    
    let folder = 'html-uploader-guide';
    if (selectedOpportunity && selectedOpportunity.key) {
        folder = selectedOpportunity.key;
    }
    
    const logs = [
        { text: 'Booting WASD Product Generator compiler environment...', type: 'info' },
        { text: `Checking opportunity tag: "${selectedOpportunity ? selectedOpportunity.title : 'AI Tool'}"`, type: 'info' },
        { text: 'Retrieving clean client layout specifications...', type: 'info' },
        { text: `Preparing deployment path: products/${folder}/index.html`, type: 'info' },
        { text: 'Bundling glassmorphic style tags and Google Font imports...', type: 'info' }
    ];
    
    // Add write log
    if (engineMode === 'local' && serverConnected) {
        logs.push({ text: 'Contacting local write-product backend proxy on port 5000...', type: 'cmd' });
        logs.push({ text: `Writing active HTML code template directly to local workspace disk...`, type: 'cmd' });
    } else {
        logs.push({ text: 'Warning: Local proxy server is offline. Compiling in sandboxed browser cache only.', type: 'info' });
    }
    
    logs.push({ text: 'Verifying relative import hierarchies...', type: 'info' });
    logs.push({ text: `Compilation success: products/${folder}/index.html created successfully.`, type: 'success' });
    
    let idx = 0;
    
    function logLine() {
        if (idx >= logs.length) {
            // Write files physically if local server is connected
            if (engineMode === 'local' && serverConnected) {
                writeProductToDisk(folder);
            } else {
                finishBuildUI(folder);
            }
            return;
        }
        
        const log = logs[idx];
        const line = document.createElement('div');
        line.className = 'terminal-line';
        if (log.type === 'cmd') {
            line.innerHTML = `<span class="term-cmd">$</span> ${log.text}`;
        } else if (log.type === 'success') {
            line.innerHTML = `<span class="term-success">✔</span> ${log.text}`;
        } else {
            line.innerHTML = `<span class="term-info">ℹ</span> ${log.text}`;
        }
        terminal.appendChild(line);
        terminal.scrollTop = terminal.scrollHeight;
        
        idx++;
        setTimeout(logLine, Math.random() * 200 + 100);
    }
    
    setTimeout(logLine, 200);
}

// Send the HTML code to local Python server to physically write to disk
function writeProductToDisk(folder) {
    const template = productTemplates[folder] || productTemplates['html-uploader-guide'];
    const terminal = document.getElementById('build-terminal-log');
    
    const payload = {
        folder_name: template.folder,
        file_name: template.fileName,
        content: template.content
    };
    
    const line = document.createElement('div');
    line.className = 'terminal-line';
    line.innerHTML = '<span class="term-cmd">$</span> Performing hidden API write request...';
    terminal.appendChild(line);
    
    fetch('http://localhost:5000/api/write-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: jsonStringifySilent(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const successLine = document.createElement('div');
            successLine.className = 'terminal-line';
            successLine.innerHTML = `<span class="term-success">✔</span> Written to: <code>${data.path}</code> (Verified physically on your disk!)`;
            terminal.appendChild(successLine);
        } else {
            const errLine = document.createElement('div');
            errLine.className = 'terminal-line';
            errLine.innerHTML = `<span class="term-info">⚠</span> Backend write failed: ${data.error}. Saved in memory sandbox instead.`;
            terminal.appendChild(errLine);
        }
        finishBuildUI(folder);
    })
    .catch(err => {
        const errLine = document.createElement('div');
        errLine.className = 'terminal-line';
        errLine.innerHTML = `<span class="term-info">⚠</span> API write failed (CORS/Network error). Saved in memory sandbox instead.`;
        terminal.appendChild(errLine);
        finishBuildUI(folder);
    });
}

function finishBuildUI(folder) {
    const backBtn = document.getElementById('btn-build-back');
    const banner = document.getElementById('build-success-banner');
    const buildSub = document.getElementById('build-subtitle');
    
    backBtn.disabled = false;
    banner.style.display = 'flex';
    buildSub.innerText = 'Asset deployment sequence finalized.';
    markStepCompleted(7);
    
    // Set preview iframe src
    const path = `products/${folder}/index.html`;
    const iframe = document.getElementById('preview-iframe-element');
    iframe.src = path;
    
    // Update modal icons
    const iconMap = {
        'resume-optimizer': '📄',
        'questionnaire-reviewer': '📝',
        'study-buddy': '🤖',
        'html-uploader-guide': '🌐'
    };
    document.getElementById('preview-modal-icon').innerText = iconMap[folder] || '⚙️';
    document.getElementById('preview-modal-title').innerText = selectedOpportunity ? selectedOpportunity.title : 'Built App';
}

// Modal handlers
function openPreviewModal() {
    document.getElementById('preview-modal-element').classList.add('active');
}

function closePreviewModal() {
    document.getElementById('preview-modal-element').classList.remove('active');
    
    // Reset iframe to stop running scripts
    const iframe = document.getElementById('preview-iframe-element');
    const prevSrc = iframe.src;
    iframe.src = 'about:blank';
    setTimeout(() => {
        iframe.src = prevSrc;
    }, 100);
}
