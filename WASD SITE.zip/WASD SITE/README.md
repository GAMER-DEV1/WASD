# WASD Launchpad – AI Product Generator

A professional dashboard that connects to a local AI backend to scan opportunity topics, analyze consumer cohorts, and physicalize standalone HTML products.

## Project Structure

```
WASD SITE/
├── index.html          – Main Launchpad dashboard
├── index.css           – Dashboard styles
├── app.js              – Dashboard logic, health checks, step navigation
├── chatbot.html        – Student Buddy (SB) chat interface
├── chatbot.css         – Chat interface styles
├── chatbot.js          – Chat message handling & SB integration
├── assets/
│   └── images/
│       └── logo.svg    – SB bot logo
├── local-model/
│   ├── server.py       – Python HTTP server (port 5000) hosting the AI backend
│   ├── knowledge_base.py – SB persona, QA dictionary, profanity filter, name memory
│   ├── requirements.txt  – Python dependencies (transformers, torch)
│   └── README.md       – Local model documentation
└── products/           – Generated product output folder
```

## Quick Start

### 1. Install Python Dependencies

```bash
cd local-model
pip install -r requirements.txt
```

### 2. Start the Local Server

```bash
python server.py
```

The server runs on `http://localhost:5000`.

### 3. Open the Dashboard

Open `index.html` in your browser. The sidebar will show:
- **Engine status** (connected / offline)
- **Chat with SB** link → opens `chatbot.html`

### 4. Chat with Student Buddy

Click the **"Chat with SB"** button in the sidebar, or open `chatbot.html` directly.  
SB will greet you with: *"yo, i am SB – your personal study buddy. What's your name?"*

## Student Buddy (SB) Features

| Feature | Description |
|---------|-------------|
| **Instant QA** | Pre-loaded answers for common student questions (photosynthesis, Newton's laws, etc.) |
| **Name Memory** | Remembers your name across the session |
| **Profanity Filter** | Censors offensive words and shows a warning |
| **Multilingual** | Supports Igbo, Yoruba, French, Japanese, Chinese, Korean, Arabic (Iraq) |
| **Games** | Trivia, word puzzles, math challenges |
| **Fallback** | Unknown questions receive "I will send you the update soon." |

## License

Internal project – all rights reserved.
