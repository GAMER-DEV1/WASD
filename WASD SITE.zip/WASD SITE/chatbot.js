// chatbot.js – Student Buddy (SB) standalone chat logic
// This file is loaded by chatbot.html and handles all message flow.

(function () {
    'use strict';

    const SERVER_URL = 'http://localhost:5000/api/proxy-llm';
    const messagesEl = document.getElementById('chat-messages');
    const inputEl = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const typingEl = document.getElementById('typing-indicator');

    // -----------------------------------------------------------------
    // Render helpers
    // -----------------------------------------------------------------
    function addMessage(text, who) {
        const row = document.createElement('div');
        row.className = `msg-row ${who}`;

        const avatar = document.createElement('div');
        avatar.className = 'msg-avatar';
        avatar.textContent = who === 'user' ? '🧑' : '🤖';

        const bubble = document.createElement('div');
        bubble.className = 'msg-bubble';

        // Check for offensive‑language warning prefix
        if (who === 'bot' && text.startsWith('[⚠️')) {
            const warnEnd = text.indexOf(']');
            if (warnEnd !== -1) {
                const warnSpan = document.createElement('span');
                warnSpan.className = 'warning-bar';
                warnSpan.textContent = text.substring(0, warnEnd + 1);
                bubble.appendChild(warnSpan);
                text = text.substring(warnEnd + 1).trim();
            }
        }

        const content = document.createElement('span');
        content.textContent = text;
        bubble.appendChild(content);

        row.appendChild(avatar);
        row.appendChild(bubble);
        messagesEl.appendChild(row);
        messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function showTyping() { typingEl.style.display = 'flex'; messagesEl.scrollTop = messagesEl.scrollHeight; }
    function hideTyping() { typingEl.style.display = 'none'; }

    // -----------------------------------------------------------------
    // Send message
    // -----------------------------------------------------------------
    async function sendMessage() {
        const text = inputEl.value.trim();
        if (!text) return;

        addMessage(text, 'user');
        inputEl.value = '';
        inputEl.disabled = true;
        sendBtn.disabled = true;
        showTyping();

        try {
            const resp = await fetch(SERVER_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: text, system_prompt: '' })
            });
            const data = await resp.json();

            hideTyping();
            if (data.success) {
                addMessage(data.text, 'bot');
            } else {
                addMessage('[⚠️ Error] ' + (data.error || 'Unknown error'), 'bot');
            }
        } catch (e) {
            hideTyping();
            addMessage('[⚠️ Network error] ' + e.message, 'bot');
        } finally {
            inputEl.disabled = false;
            sendBtn.disabled = false;
            inputEl.focus();
        }
    }

    // -----------------------------------------------------------------
    // Event listeners
    // -----------------------------------------------------------------
    sendBtn.addEventListener('click', sendMessage);
    inputEl.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Auto‑resize textarea
    inputEl.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });

    // -----------------------------------------------------------------
    // SB intro greeting
    // -----------------------------------------------------------------
    addMessage('yo, i am SB – your personal study buddy 📚 What\'s your name?', 'bot');
})();
